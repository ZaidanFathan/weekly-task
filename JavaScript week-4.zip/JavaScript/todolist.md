1. Validasi form dan gunakan alert dialog untuk memunculkan pesan (✅)
2. Burger menu pada saat halaman mengecil(✅)
3. responsive (✅)
